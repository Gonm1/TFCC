/*
 * Integrantes:
 * 	- Manuel Lepe Fa�ndez.
 * 	- Gonzalo Miranda Cabrera.
*/
public class Transicion{
	String sj;
	String si;
	String qj;
	String movimiento;
	Transicion sig;

	public Transicion(String sii,String sjj,String qjj,String movimiento1){
		sj=sjj;
		si=sii;
		qj=qjj;
		movimiento=movimiento1;
	}
}