Proyecto Fundamentos de las Ciencias de la Computacion.
Integrantes:
	- Manuel Lepe Fa�ndez.
	- Gonzalo Miranda Cabrera.

Al ejecutar el programa por favor tener las siguientes consideraciones:
1.- Ejecutar el archivo InterfaceUno.java ya que esta es la clase que contiene el main.
2.- Los estados sin transiciones que se utilicen en la maquina de turing no deben ser agregados en el archivo xml.
3.- En la opcion de Reconocimiento por lotes se deben agregar las cadenas en el siguiente formato: ejemplo1,ejemplo2,ejemplo3
4.- En la opcion de Reconocimiento por lotes la ultima cadena agregada no debe llevar coma.
5.- En la opcion reconocimiento individual la cadena ingresada no debe llevar espacios en blanco al final.